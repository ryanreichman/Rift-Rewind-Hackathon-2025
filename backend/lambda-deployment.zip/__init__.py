"""Backend package for AI Chat Agent."""

__version__ = "1.0.0"
